<img src="{{ asset('img/icon.svg')}}" style="width:50px;" class="m-auto"> 
